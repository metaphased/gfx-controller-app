// control.js — Esports GFX Control Panel

const socket = io();
window._state = {};
let bracketRounds = [];
const _pickerContainers = {};
const DEFAULT_ROLES = ['Top', 'Jungle', 'Mid', 'ADC', 'Support'];

// ── Connection ─────────────────────────────────────────────────────────────────
socket.on('connect', () => {
  const el = g('conn-status');
  el.textContent = '⬤ Connected';
  el.className = 'connection-status connected';
});
socket.on('disconnect', () => {
  const el = g('conn-status');
  el.textContent = '⬤ Disconnected';
  el.className = 'connection-status disconnected';
});
socket.on('state', (state) => {
  window._state = state;
  syncUI(state);
});

// ── Navigation ─────────────────────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach(navEl => {
  navEl.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    navEl.classList.add('active');
    const tab = g('tab-' + navEl.dataset.tab);
    if (tab) tab.classList.add('active');
    if (navEl.dataset.tab === 'teams') renderTeamsList();
  });
});

// Output URL chips
const GFX_PAGES = [
  ['Scoreboard',   'graphics/scoreboard/'],
  ['Lower Third',  'graphics/lower-third/'],
  ['Head to Head', 'graphics/head2head/'],
  ['Champ Select', 'graphics/champ-select/'],
  ['Bracket',      'graphics/bracket/'],
  ['Break Screen', 'graphics/break-screen/'],
  ['Win Screen',   'graphics/win-screen/'],
];
const urlList = g('url-list');
GFX_PAGES.forEach(([label, p]) => {
  const url = 'http://localhost:3000/' + p;
  const chip = document.createElement('div');
  chip.className = 'url-chip';
  chip.title = 'Click to copy';
  chip.textContent = label;
  chip.addEventListener('click', () => {
    navigator.clipboard.writeText(url).then(() => {
      chip.textContent = '✓ Copied!';
      setTimeout(() => { chip.textContent = label; }, 1500);
    });
  });
  urlList.appendChild(chip);
});

// ── API helper ─────────────────────────────────────────────────────────────────
async function api(path, body) {
  try {
    const res = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (!res.ok) { const err = await res.json().catch(() => ({})); console.error('API error', path, res.status, err); }
    return res.json().catch(() => ({}));
  } catch (e) { console.error('Fetch error', path, e); }
}

// ── Sync UI ────────────────────────────────────────────────────────────────────
function syncUI(s) {
  if (!s || !s.match || !s.lowerThird || !s.champSelect || !s.breakScreen || !s.winScreen || !s.bracket || !s.players) {
    console.warn('Incomplete state', s); return;
  }
  const m = s.match, p = s.players;

  setInp('tournament-name', m.tournament);
  setInp('match-format', m.format);
  setInp('match-game', m.game);
  setInp('tournament-logo', m.tournamentLogo);

  setInp('t1-name', m.team1.name); setInp('t1-tag', m.team1.tag); setInp('t1-logo', m.team1.logo);
  setInp('t1-color-text', m.team1.color); setColorPicker('t1-color', m.team1.color);
  setSpan('t1-score', m.team1.score); setDotColor('t1-dot', m.team1.color);

  setInp('t2-name', m.team2.name); setInp('t2-tag', m.team2.tag); setInp('t2-logo', m.team2.logo);
  setInp('t2-color-text', m.team2.color); setColorPicker('t2-color', m.team2.color);
  setSpan('t2-score', m.team2.score); setDotColor('t2-dot', m.team2.color);

  setText('ls-t1-name', m.team1.name); setText('ls-t2-name', m.team2.name);
  setText('ls-t1-score', m.team1.score); setText('ls-t2-score', m.team2.score);

  setText('players-t1-label', m.team1.name + ' Roster');
  setText('players-t2-label', m.team2.name + ' Roster');
  setText('cs-t1-label', m.team1.name + ' Draft');
  setText('cs-t2-label', m.team2.name + ' Draft');

  setInpSafe('lt-text', s.lowerThird.text); setInpSafe('lt-sub', s.lowerThird.subtext); setInpSafe('lt-super', s.lowerThird.supertext);
  setInpSafe('break-msg', s.breakScreen.message); setInpSafe('break-sub', s.breakScreen.subtext); setInpSafe('break-next', s.breakScreen.nextMatch);
  setInpSafe('win-msg', s.winScreen.message); setInpSafe('bracket-title', s.bracket.title);

  renderSponsors(m.sponsorLogos || []);
  renderPlayerEditors(p);
  renderLTQuickGrid(p, m);
  renderCSInputs(s.champSelect);
  syncGraphicIndicators(s);
  syncOperatorPage(s);
  syncLiveBar(s);

  if (s.bracket && s.bracket.rounds) { bracketRounds = s.bracket.rounds; renderBracketEditor(); }
}

// ── DOM helpers ────────────────────────────────────────────────────────────────
function g(id) { return document.getElementById(id); }
function setInp(id, val) { const e = g(id); if (e && document.activeElement !== e) e.value = val != null ? val : ''; }
function setInpSafe(id, val) { setInp(id, val); }
function setText(id, val) { const e = g(id); if (e) e.textContent = val != null ? val : ''; }
function setSpan(id, val) { setText(id, val); }
function setColorPicker(id, val) { const e = g(id); if (e && val && /^#[0-9a-fA-F]{6}$/.test(val)) e.value = val; }
function setDotColor(id, color) { const e = g(id); if (e) e.style.background = color || '#1ffaff'; }

// ── Match ──────────────────────────────────────────────────────────────────────
function patchMatch(data) { api('/api/match', data); }
function patchTeam(n, field, value) { socket.emit('state:patch', { match: { ['team'+n]: { [field]: value } } }); }
function syncColorFromPicker(n, hex) { const t = g('t'+n+'-color-text'); if (t && document.activeElement!==t) t.value=hex; patchTeam(n,'color',hex); }
function syncColorFromText(n, hex) { if (/^#[0-9a-fA-F]{6}$/.test(hex)) { setColorPicker('t'+n+'-color',hex); patchTeam(n,'color',hex); } }
function getLTColor(k) { return (window._state&&window._state.match&&window._state.match[k]&&window._state.match[k].color)||'#1ffaff'; }
function patchScore(team, delta) { api('/api/score', { team, delta }); }
function resetState() { if (confirm('Reset ALL state? Cannot be undone.')) api('/api/state/reset', {}); }

// ── Graphics ───────────────────────────────────────────────────────────────────
function showGraphic(name) { fetch('/api/graphic/'+name+'/show',{method:'POST'}).catch(console.error); }
function hideGraphic(name) { fetch('/api/graphic/'+name+'/hide',{method:'POST'}).catch(console.error); }

// ── Lower Third ────────────────────────────────────────────────────────────────
function patchLT(data) { api('/api/lowerThird', data); }

function renderLTQuickGrid(players, match) {
  const grid = g('lt-player-grid'); if (!grid) return;
  const all = [];
  (players.team1||[]).forEach(p => { if (p.handle||p.name) all.push({...p, teamName:match.team1.name, teamTag:match.team1.tag, teamColor:match.team1.color}); });
  (players.team2||[]).forEach(p => { if (p.handle||p.name) all.push({...p, teamName:match.team2.name, teamTag:match.team2.tag, teamColor:match.team2.color}); });
  grid._players = all;
  grid.innerHTML = all.map((p,i) =>
    '<button class="player-quick-btn" onclick="quickLT('+i+')">' +
    '<span class="pqb-handle">'+esc(p.handle||p.name)+'</span>' +
    '<span class="pqb-team">'+esc(p.teamTag||p.teamName)+(p.role?' · '+p.role:'')+'</span>' +
    '</button>'
  ).join('');
}

function quickLT(i) {
  const grid = g('lt-player-grid');
  const p = grid&&grid._players&&grid._players[i]; if (!p) return;
  api('/api/lowerThird', { text:p.handle||p.name, subtext:(p.role?p.role+' · ':'')+p.teamName, supertext:(window._state&&window._state.match&&window._state.match.tournament)||'', teamColor:p.teamColor||'', visible:true });
}

// ── Champ Select ───────────────────────────────────────────────────────────────
function patchCS(data) { api('/api/champSelect', data); }
function updateCS(team, type, index, url) {
  const cs = window._state&&window._state.champSelect;
  const cur = (cs&&cs[team]&&cs[team][type]) ? cs[team][type].slice() : ['','','','',''];
  cur[index] = url;
  api('/api/champSelect', { [team]: { [type]: cur } });
}

function renderCSInputs(cs) {
  if (!cs) return;
  ['team1','team2'].forEach(function(team) {
    const prefix = team==='team1'?'t1':'t2';
    ['bans','picks'].forEach(function(type) {
      const container = g('cs-'+prefix+'-'+type+'-inputs'); if (!container) return;
      const values = (cs[team]&&cs[team][type]) ? cs[team][type] : ['','','','',''];
      const labels = type==='bans' ? ['Ban 1','Ban 2','Ban 3','Ban 4','Ban 5'] : ['Pick 1','Pick 2','Pick 3','Pick 4','Pick 5'];
      if (!container.dataset.built) {
        container.dataset.built = '1'; container.innerHTML = '';
        values.forEach(function(val, i) {
          const key = team+'-'+type+'-'+i;
          const row = document.createElement('div'); row.className = 'cs-input-row cs-picker-row';
          const lbl = document.createElement('label'); lbl.textContent = labels[i];
          const pc = document.createElement('div'); pc.className = 'cs-picker-container';
          row.appendChild(lbl); row.appendChild(pc); container.appendChild(row);
          _pickerContainers[key] = pc;
          Champions.buildPicker(pc, function(champ) { updateCS(team, type, i, champ.url||''); }, val);
        });
      } else {
        values.forEach(function(val, i) {
          const pc = _pickerContainers[team+'-'+type+'-'+i];
          if (pc) Champions.updatePickerValue(pc, val);
        });
      }
    });
  });
}

// ── Break / Win ────────────────────────────────────────────────────────────────
function patchBreak(data) { api('/api/breakScreen', data); }
function startBreakTimer() { const m=parseInt(g('break-timer-min').value)||0, s=parseInt(g('break-timer-sec').value)||0; api('/api/breakScreen',{timerEnd:Date.now()+(m*60+s)*1000}); }
function clearBreakTimer() { api('/api/breakScreen',{timerEnd:null}); }
function patchWin(data) { api('/api/winScreen', data); }

// ── Bracket ────────────────────────────────────────────────────────────────────
function patchBracket(data) { api('/api/bracket', data); }
function syncBracket() { api('/api/bracket', { rounds: bracketRounds }); }
function addBracketRound() {
  bracketRounds.push({ label:'Round '+(bracketRounds.length+1), matches:[{team1:{name:'',score:0},team2:{name:'',score:0},complete:false}] });
  renderBracketEditor(); syncBracket();
}
function addBracketMatch(ri) {
  if (!bracketRounds[ri]) return;
  bracketRounds[ri].matches.push({team1:{name:'',score:0},team2:{name:'',score:0},complete:false});
  renderBracketEditor(); syncBracket();
}
function removeBracketRound(ri) { bracketRounds.splice(ri,1); renderBracketEditor(); syncBracket(); }

// Build a team <select> for bracket slots — options from teams DB + manual entry
function bracketTeamSelect(ri, mi, side, currentName) {
  const teams = window._bracketTeams || [];
  const safeVal = esc(currentName||'');
  let opts = '<option value="">— TBD —</option>';
  opts += teams.map(t => '<option value="'+esc(t.name)+'"'+(t.name===currentName?' selected':'')+'>'+esc(t.name)+'</option>').join('');
  // If current value isn't in the list keep it as custom text shown separately
  return '<select class="br-'+side+'name-sel" data-ri="'+ri+'" data-mi="'+mi+'" data-side="'+side+'">'+opts+'</select>';
}

function renderBracketEditor() {
  const container = g('bracket-rounds'); if (!container) return;
  container.innerHTML = bracketRounds.map(function(round, ri) {
    return '<div class="bracket-round">' +
      '<div class="bracket-round-header">' +
        '<input type="text" class="br-label" data-ri="'+ri+'" value="'+esc(round.label||'')+'" style="flex:1;font-weight:700" placeholder="Round name">' +
        '<button class="btn btn-sm btn-danger" onclick="removeBracketRound('+ri+')">Remove Round</button>' +
      '</div>' +
      round.matches.map(function(match, mi) {
        return '<div class="bracket-match">' +
          bracketTeamSelect(ri,mi,'t1',match.team1&&match.team1.name) +
          '<input type="number" class="br-t1score score-in" data-ri="'+ri+'" data-mi="'+mi+'" placeholder="S" min="0" value="'+((match.team1&&match.team1.score!=null)?match.team1.score:'')+'">' +
          '<span style="color:var(--accent);font-weight:700;padding:0 6px">vs</span>' +
          bracketTeamSelect(ri,mi,'t2',match.team2&&match.team2.name) +
          '<input type="number" class="br-t2score score-in" data-ri="'+ri+'" data-mi="'+mi+'" placeholder="S" min="0" value="'+((match.team2&&match.team2.score!=null)?match.team2.score:'')+'">' +
          '<label style="display:flex;align-items:center;gap:4px;font-size:12px;color:var(--accent);white-space:nowrap">' +
            '<input type="checkbox" class="br-done" data-ri="'+ri+'" data-mi="'+mi+'"'+(match.complete?' checked':'')+'>Done</label>' +
          '</div>';
      }).join('') +
      '<button class="btn btn-sm" style="margin-top:6px" onclick="addBracketMatch('+ri+')">+ Add Match</button>' +
      '</div>';
  }).join('');
  container.oninput  = handleBracketInput;
  container.onchange = handleBracketInput;
}

function handleBracketInput(e) {
  const t = e.target;
  const ri = parseInt(t.dataset.ri);
  const mi = parseInt(t.dataset.mi);
  if (isNaN(ri)||!bracketRounds[ri]) return;
  if (t.classList.contains('br-label')) { bracketRounds[ri].label = t.value; }
  else if (!isNaN(mi) && bracketRounds[ri].matches[mi]) {
    const match = bracketRounds[ri].matches[mi];
    if (t.classList.contains('br-t1name-sel')) match.team1.name  = t.value;
    if (t.classList.contains('br-t1score'))    match.team1.score = parseInt(t.value)||0;
    if (t.classList.contains('br-t2name-sel')) match.team2.name  = t.value;
    if (t.classList.contains('br-t2score'))    match.team2.score = parseInt(t.value)||0;
    if (t.classList.contains('br-done'))       match.complete    = t.checked;
  }
  syncBracket();
}

// Load teams into bracket selects cache then re-render
async function refreshBracketTeams() {
  const res = await fetch('/api/teams').then(r=>r.json()).catch(()=>({teams:[]}));
  window._bracketTeams = res.teams || [];
}

// ── Players + Subs ─────────────────────────────────────────────────────────────
function renderPlayerEditors(players) {
  ['team1','team2'].forEach(function(team) {
    const prefix = team==='team1'?'t1':'t2';
    const container = g(prefix+'-roster'); if (!container) return;
    const list    = players[team] || [];
    const subList = players[team+'subs'] || [];

    // ── Build DOM structure once only ──
    if (!container.dataset.built) {
      container.dataset.built = '1';

      let html = '<div class="roster-section-label">STARTING LINEUP</div>';
      html += list.map(function(p, i) {
        return '<div class="player-row-edit">' +
          '<div><div class="player-num">'+DEFAULT_ROLES[i]+'</div>' +
            '<input type="text" data-team="'+team+'" data-index="'+i+'" data-field="handle" placeholder="Handle / IGN"></div>' +
          '<div><div class="player-num">Role</div>' +
            '<input type="text" data-team="'+team+'" data-index="'+i+'" data-field="role" placeholder="Role"></div>' +
          '<div><div class="player-num">Swap Sub</div>' +
            '<select class="sub-swap-sel" data-team="'+team+'" data-player-index="'+i+'" title="Swap with sub">' +
              '<option value="">—</option>' +
            '</select>' +
          '</div>' +
          '</div>';
      }).join('');

      html += '<div class="roster-section-label" style="margin-top:14px">SUBSTITUTES</div>';
      html += subList.map(function(s, i) {
        return '<div class="player-row-edit sub-row">' +
          '<div><div class="player-num">Sub '+(i+1)+'</div>' +
            '<input type="text" data-team="'+team+'" data-subindex="'+i+'" data-field="handle" placeholder="Handle / IGN"></div>' +
          '<div><div class="player-num">Role</div>' +
            '<input type="text" data-team="'+team+'" data-subindex="'+i+'" data-field="role" placeholder="Role"></div>' +
          '<div></div>' +
          '</div>';
      }).join('');

      container.innerHTML = html;

      // Input handler
      container.addEventListener('input', function(e) {
        const inp = e.target; if (inp.tagName !== 'INPUT') return;
        if (inp.dataset.subindex !== undefined) {
          api('/api/subs', { team, index: parseInt(inp.dataset.subindex), data: { [inp.dataset.field]: inp.value } });
        } else if (inp.dataset.index !== undefined) {
          api('/api/players', { team, index: parseInt(inp.dataset.index), data: { [inp.dataset.field]: inp.value } });
        }
      });

      // Swap select handler — reads current list/subList from state at time of change
      container.addEventListener('change', function(e) {
        const sel = e.target;
        if (!sel.classList.contains('sub-swap-sel')) return;
        const playerIndex = parseInt(sel.dataset.playerIndex);
        const subIndex    = parseInt(sel.value);
        if (isNaN(subIndex)) return;
        const currentList    = (window._state && window._state.players && window._state.players[team]) || [];
        const currentSubList = (window._state && window._state.players && window._state.players[team+'subs']) || [];
        const pName = (currentList[playerIndex]    && (currentList[playerIndex].handle    || currentList[playerIndex].name))    || ('Player '+(playerIndex+1));
        const sName = (currentSubList[subIndex]    && (currentSubList[subIndex].handle    || currentSubList[subIndex].name))    || ('Sub '+(subIndex+1));
        if (confirm('Swap ' + pName + ' with ' + sName + '?')) {
          api('/api/players/swap', { team, playerIndex, subIndex });
        }
        sel.value = '';
      });
    } // end if !container.dataset.built

    // Update values every state tick — skip focused inputs to preserve typing
    container.querySelectorAll('input').forEach(function(inp) {
      if (document.activeElement === inp) return;
      if (inp.dataset.subindex !== undefined) {
        const s = subList[inp.dataset.subindex];
        if (s) inp.value = s[inp.dataset.field] || '';
      } else if (inp.dataset.index !== undefined) {
        const p = list[inp.dataset.index];
        if (p) inp.value = p[inp.dataset.field] || '';
      }
    });

    // Refresh swap dropdown options with current sub names
    container.querySelectorAll('.sub-swap-sel').forEach(function(sel) {
      sel.innerHTML = '<option value="">Swap sub...</option>' +
        subList.map(function(s, si) {
          return (s.handle || s.name)
            ? '<option value="' + si + '">⇕ ' + (s.handle || s.name).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') + '</option>'
            : '';
        }).join('');
    });

  });
}

function updatePlayer(team, index, field, value) { api('/api/players', { team, index, data: { [field]: value } }); }

// ── Sponsors ───────────────────────────────────────────────────────────────────
function renderSponsors(logos) {
  const el = g('sponsor-list'); if (!el) return;
  el.innerHTML = logos.map(function(url, i) {
    return '<div class="sponsor-chip"><img src="'+url+'" alt=""><span style="max-width:80px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px">'+url.split('/').pop()+'</span><button onclick="removeSponsor('+i+')">✕</button></div>';
  }).join('');
}
function addSponsor() { triggerUpload('sponsor-file', function(url) { const logos=((window._state&&window._state.match&&window._state.match.sponsorLogos)||[]).concat([url]); api('/api/match',{sponsorLogos:logos}); }); }
function removeSponsor(i) { const logos=((window._state&&window._state.match&&window._state.match.sponsorLogos)||[]).slice(); logos.splice(i,1); api('/api/match',{sponsorLogos:logos}); }

// ── Upload ─────────────────────────────────────────────────────────────────────
function triggerUpload(inputId, callback) {
  const inp = g(inputId); if (!inp) return;
  inp.onchange = async function() {
    const file = inp.files[0]; if (!file) return;
    const fd = new FormData(); fd.append('file', file);
    try { const res = await fetch('/api/upload',{method:'POST',body:fd}); const data = await res.json(); if (data.url) callback(data.url); }
    catch(e) { console.error('Upload error',e); }
    inp.value = '';
  };
  inp.click();
}

// ── Import ─────────────────────────────────────────────────────────────────────
async function importGSheets() {
  const sheetId=(g('gsheets-id').value||'').trim(), apiKey=(g('gsheets-key').value||'').trim(), range=(g('gsheets-range').value||'Sheet1').trim();
  if (!sheetId||!apiKey) return showImportResult('gsheets-result','Sheet ID and API Key required.',true);
  showImportResult('gsheets-result','Importing…',false);
  const res = await api('/api/import/gsheets',{sheetId,apiKey,range});
  if (!res||res.error) return showImportResult('gsheets-result','Error: '+(res&&res.error?res.error:'unknown'),true);
  applyImportedPlayers(res.data||[]);
  showImportResult('gsheets-result','✓ Imported '+(res.data||[]).length+' rows');
}
async function importJson() {
  const file=g('json-file')&&g('json-file').files[0]; if (!file) return showImportResult('import-result','Select a JSON file.',true);
  const fd=new FormData(); fd.append('file',file);
  const res=await fetch('/api/import/json',{method:'POST',body:fd}).then(r=>r.json()).catch(()=>({error:'Upload failed'}));
  if (res.error) return showImportResult('import-result','Error: '+res.error,true);
  applyImportedPlayers(Array.isArray(res.data)?res.data:[res.data]);
  showImportResult('import-result','✓ Imported from JSON');
}
async function importCsv() {
  const file=g('csv-file')&&g('csv-file').files[0]; if (!file) return showImportResult('import-result','Select a CSV file.',true);
  const fd=new FormData(); fd.append('file',file);
  const res=await fetch('/api/import/csv',{method:'POST',body:fd}).then(r=>r.json()).catch(()=>({error:'Upload failed'}));
  if (res.error) return showImportResult('import-result','Error: '+res.error,true);
  applyImportedPlayers(res.data||[]);
  showImportResult('import-result','✓ Imported '+(res.data||[]).length+' rows');
}
function applyImportedPlayers(rows) {
  if (!Array.isArray(rows)||!rows.length) return;
  const m=window._state&&window._state.match, t1=(m&&m.team1)||{};
  const t1keys=['1','team1',(t1.tag||'').toLowerCase(),(t1.name||'').toLowerCase()].filter(Boolean);
  const buckets={team1:[],team2:[]};
  rows.forEach(function(row){ buckets[t1keys.indexOf((row.team||'').toLowerCase().trim())!==-1?'team1':'team2'].push(row); });
  ['team1','team2'].forEach(function(team){
    buckets[team].forEach(function(row,i){ if(i>=5)return; api('/api/players',{team,index:i,data:{handle:row.handle||row.ign||'',name:row.name||'',role:row.role||'',country:row.country||''}}); });
  });
}
function showImportResult(id, msg, isError) {
  const el=g(id); if(!el)return; el.textContent=msg; el.className='import-result show'+(isError?' error':'');
  setTimeout(function(){el.className='import-result';},5000);
}

// ── Teams Database ─────────────────────────────────────────────────────────────
async function renderTeamsList() {
  const container=g('teams-list'), empty=g('teams-empty'); if(!container)return;
  const res=await fetch('/api/teams').then(r=>r.json()).catch(()=>({teams:[]}));
  const teams=res.teams||[];
  if(!teams.length){container.innerHTML='';if(empty)empty.style.display='block';return;}
  if(empty)empty.style.display='none';
  container.innerHTML=teams.map(function(team){
    const logo=team.logo?'<img src="'+team.logo+'" style="width:44px;height:44px;object-fit:contain;flex-shrink:0">':'<div style="width:44px;height:44px;background:var(--bg3);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:9px;color:var(--text-dim);flex-shrink:0">LOGO</div>';
    const dot='width:10px;height:10px;border-radius:50%;background:'+(team.color||'#1ffaff')+';display:inline-block;margin-right:6px;flex-shrink:0';
    const pc=(team.players||[]).filter(function(p){return p.handle||p.name;}).length;
    const sc=(team.subs||[]).filter(function(s){return s.handle||s.name;}).length;
    return '<div class="team-db-row">'+logo+
      '<div style="flex:1;min-width:0">'+
        '<div style="display:flex;align-items:center;gap:6px"><div style="'+dot+'"></div>'+
          '<span style="font-family:\'Barlow Condensed\',sans-serif;font-size:18px;font-weight:800;color:#fff;text-transform:uppercase">'+esc(team.name)+'</span>'+
          '<span style="font-size:11px;color:var(--accent);letter-spacing:0.12em">'+esc(team.tag||'')+'</span></div>'+
        '<div style="font-size:11px;color:var(--text-dim);margin-top:2px">'+pc+' player'+(pc!==1?'s':'')+' · '+sc+' sub'+(sc!==1?'s':'')+'</div>'+
      '</div>'+
      '<div style="display:flex;gap:8px;flex-shrink:0">'+
        '<button class="btn btn-sm btn-primary" onclick="loadTeamIntoSlot(\''+team.id+'\',\'team1\')">→ T1</button>'+
        '<button class="btn btn-sm btn-primary" onclick="loadTeamIntoSlot(\''+team.id+'\',\'team2\')">→ T2</button>'+
        '<button class="btn btn-sm" onclick="openTeamEditor(\''+team.id+'\')">Edit</button>'+
      '</div></div>';
  }).join('');
}

async function loadTeamIntoSlot(teamId, slot) {
  const res = await api('/api/match/load-team', { slot, teamId });
  if (res&&res.ok) {
    const prefix = slot==='team1'?'t1':'t2';
    const rosterEl = g(prefix+'-roster');
    if (rosterEl) { delete rosterEl.dataset.built; delete rosterEl.dataset.sig; }
  }
}

async function openTeamEditor(teamId) {
  const editor=g('team-editor'), title=g('team-editor-title'), deleteBtn=g('delete-team-btn');
  if (!editor) return;
  editor.style.display='block';
  setTimeout(function(){editor.scrollIntoView({behavior:'smooth',block:'start'});},50);

  if (teamId) {
    const res=await fetch('/api/teams').then(r=>r.json()).catch(()=>({teams:[]}));
    const team=(res.teams||[]).find(function(t){return t.id===teamId;});
    if (!team) return;
    title.textContent='Edit Team — '+team.name;
    g('edit-team-id').value=team.id; g('edit-team-name').value=team.name||''; g('edit-team-tag').value=team.tag||'';
    g('edit-team-color').value=team.color||'#1ffaff'; g('edit-team-color-text').value=team.color||'#1ffaff';
    g('edit-team-logo').value=team.logo||''; updateEditLogoPreview(team.logo||'');
    renderEditPlayers(team.players||[], team.subs||[]);
    deleteBtn.style.display='block';
  } else {
    title.textContent='New Team';
    g('edit-team-id').value=''; g('edit-team-name').value=''; g('edit-team-tag').value='';
    g('edit-team-color').value='#1ffaff'; g('edit-team-color-text').value='#1ffaff';
    g('edit-team-logo').value=''; updateEditLogoPreview('');
    renderEditPlayers([], []);
    deleteBtn.style.display='none';
  }
}

function closeTeamEditor() { const e=g('team-editor'); if(e)e.style.display='none'; }

function updateEditLogoPreview(url) {
  const p=g('edit-team-logo-preview'); if(!p)return;
  p.innerHTML=url?'<img src="'+url+'" style="max-width:100%;max-height:100%;object-fit:contain">':'<span style="color:var(--text-dim);font-size:12px">Logo preview</span>';
}

function renderEditPlayers(players, subs) {
  const container=g('edit-team-players'); if(!container)return;

  // Starting 5 with auto-roles
  let html='<div class="roster-section-label">STARTING LINEUP</div>';
  html+=DEFAULT_ROLES.map(function(role,i){
    const p=players[i]||{};
    return '<div class="player-row-edit">'+
      '<div><div class="player-num">'+role+'</div><input type="text" class="ep-handle" data-index="'+i+'" placeholder="Handle / IGN" value="'+esc(p.handle||'')+'"></div>'+
      '<div><div class="player-num">Role</div><input type="text" class="ep-role" data-index="'+i+'" value="'+esc(p.role||role)+'" placeholder="'+role+'"></div>'+
      '</div>';
  }).join('');

  // Substitutes (up to 3)
  html+='<div class="roster-section-label" style="margin-top:14px">SUBSTITUTES (up to 3)</div>';
  html+=[0,1,2].map(function(i){
    const s=subs[i]||{};
    return '<div class="player-row-edit sub-row">'+
      '<div><div class="player-num">Sub '+(i+1)+'</div><input type="text" class="ep-sub-handle" data-subindex="'+i+'" placeholder="Handle / IGN" value="'+esc(s.handle||'')+'"></div>'+
      '<div><div class="player-num">Role</div><input type="text" class="ep-sub-role" data-subindex="'+i+'" placeholder="e.g. Top, Flex" value="'+esc(s.role||'')+'"></div>'+
      '</div>';
  }).join('');

  container.innerHTML=html;
}

async function saveTeamEditor() {
  const name=(g('edit-team-name').value||'').trim();
  if (!name){alert('Team name is required.');return;}
  const players=DEFAULT_ROLES.map(function(_,i){
    return {
      handle:(g('edit-team-players').querySelector('.ep-handle[data-index="'+i+'"]')||{}).value||'',
      name:'',
      role:  (g('edit-team-players').querySelector('.ep-role[data-index="'+i+'"]')  ||{}).value||DEFAULT_ROLES[i],
      country:''
    };
  });
  const subs=[0,1,2].map(function(i){
    return {
      handle:(g('edit-team-players').querySelector('.ep-sub-handle[data-subindex="'+i+'"]')||{}).value||'',
      name:'',
      role:  (g('edit-team-players').querySelector('.ep-sub-role[data-subindex="'+i+'"]')  ||{}).value||'',
      country:''
    };
  });
  const idVal=g('edit-team-id').value;
  const team={name,tag:(g('edit-team-tag').value||'').trim(),color:g('edit-team-color').value||'#1ffaff',logo:(g('edit-team-logo').value||'').trim(),players,subs};
  if(idVal)team.id=idVal;
  const res=await api('/api/teams/save',team);
  if(res&&res.ok){closeTeamEditor();renderTeamsList();}
}

async function deleteEditingTeam() {
  const id=g('edit-team-id').value; if(!id)return;
  const name=g('edit-team-name').value||'this team';
  if(!confirm('Delete '+name+'? Cannot be undone.'))return;
  const res=await api('/api/teams/delete',{id});
  if(res&&res.ok){closeTeamEditor();renderTeamsList();}
}

// ── Team picker modal ──────────────────────────────────────────────────────────
let _teamPickerSlot=null;

async function openTeamPicker(slot) {
  _teamPickerSlot=slot;
  const modal=g('team-picker-modal'), label=g('team-picker-slot-label'), list=g('team-picker-list');
  if(!modal||!list)return;
  label.textContent=slot==='team1'?'TEAM 1':'TEAM 2';
  list.innerHTML='<div style="color:var(--text-dim);font-size:13px;padding:12px">Loading…</div>';
  modal.style.display='flex';
  const res=await fetch('/api/teams').then(r=>r.json()).catch(()=>({teams:[]}));
  const teams=res.teams||[];
  if(!teams.length){
    list.innerHTML='<div style="color:var(--text-dim);font-size:13px;padding:20px;text-align:center">No teams saved yet.<br><br>Go to <strong style="color:var(--text)">Teams Database</strong> to create your first team.</div>';
    return;
  }
  list.innerHTML=teams.map(function(team){
    const logo=team.logo?'<img src="'+team.logo+'" style="width:52px;height:52px;object-fit:contain;flex-shrink:0">':'<div style="width:52px;height:52px;background:var(--bg3);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:9px;color:var(--text-dim);flex-shrink:0">LOGO</div>';
    const dot='width:10px;height:10px;border-radius:50%;background:'+(team.color||'#1ffaff')+';display:inline-block;margin-right:6px;flex-shrink:0';
    const pc=(team.players||[]).filter(function(p){return p.handle||p.name;}).length;
    return '<div class="team-picker-option" onclick="selectTeamFromPicker(\''+team.id+'\')">' +
      logo+'<div style="flex:1;min-width:0">'+
        '<div style="display:flex;align-items:center;gap:6px"><div style="'+dot+'"></div>'+
          '<span style="font-family:\'Barlow Condensed\',sans-serif;font-size:22px;font-weight:800;color:#fff;text-transform:uppercase">'+esc(team.name)+'</span>'+
          '<span style="font-size:11px;color:var(--accent);letter-spacing:0.12em">'+esc(team.tag||'')+'</span></div>'+
        '<div style="font-size:11px;color:var(--text-dim);margin-top:2px">'+pc+' players</div>'+
      '</div><div style="color:var(--primary);font-size:20px;flex-shrink:0">›</div></div>';
  }).join('');
}

async function selectTeamFromPicker(teamId) {
  if(!_teamPickerSlot)return;
  const res=await api('/api/match/load-team',{slot:_teamPickerSlot,teamId});
  if(res&&res.ok){
    const prefix=_teamPickerSlot==='team1'?'t1':'t2';
    const rosterEl=g(prefix+'-roster');
    if(rosterEl){delete rosterEl.dataset.built;delete rosterEl.dataset.sig;}
    closeTeamPicker();
  }
}

function closeTeamPicker() { const m=g('team-picker-modal'); if(m)m.style.display='none'; _teamPickerSlot=null; }
g('team-picker-modal').addEventListener('click', function(e){ if(e.target===this)closeTeamPicker(); });

// ── Utility ────────────────────────────────────────────────────────────────────
function esc(str) { return String(str||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// ── Init ───────────────────────────────────────────────────────────────────────
Champions.load();
refreshBracketTeams();

// ── Graphic status indicators ──────────────────────────────────────────────────
// Maps state key -> sidebar nav data-tab and operator card id
const GRAPHIC_MAP = [
  { key: 'scoreboard',  tab: 'scoreboard',  label: 'Scoreboard'  },
  { key: 'lowerThird',  tab: 'lowerthird',  label: 'Lower Third' },
  { key: 'headToHead',  tab: 'h2h',         label: 'Head to Head'},
  { key: 'champSelect', tab: 'champselect', label: 'Champ Select'},
  { key: 'bracket',     tab: 'bracket',     label: 'Bracket'     },
  { key: 'breakScreen', tab: 'break',       label: 'Break Screen'},
  { key: 'winScreen',   tab: 'win',         label: 'Win Screen'  },
];

function syncGraphicIndicators(s) {
  GRAPHIC_MAP.forEach(function(gfx) {
    const active = s[gfx.key] && s[gfx.key].visible;
    // Sidebar dot
    const dot = g('nav-dot-' + gfx.tab);
    if (dot) {
      dot.className = 'nav-status-dot' + (active ? ' active' : '');
    }
    // Individual tab SHOW/HIDE buttons
    const showBtn = g('showbtn-' + gfx.key);
    const hideBtn = g('hidebtn-' + gfx.key);
    if (showBtn) showBtn.className = 'btn ' + (active ? 'btn-active-gfx' : 'btn-primary');
    if (hideBtn) hideBtn.className = 'btn ' + (active ? 'btn-danger' : 'btn-dim');
  });
}

// ── Operator page sync ─────────────────────────────────────────────────────────
function syncOperatorPage(s) {
  const m = s.match;

  // Score displays
  setText('ops-t1-name',  m.team1.name);
  setText('ops-t2-name',  m.team2.name);
  setText('ops-t1-score', m.team1.score);
  setText('ops-t2-score', m.team2.score);

  // Lower third fields
  setInpSafe('ops-lt-text',  s.lowerThird.text);
  setInpSafe('ops-lt-sub',   s.lowerThird.subtext);
  setInpSafe('ops-lt-super', s.lowerThird.supertext);

  // Break screen fields
  setInpSafe('ops-break-msg',  s.breakScreen.message);
  setInpSafe('ops-break-next', s.breakScreen.nextMatch);

  // Win screen
  const wr1 = g('ops-win-team1'); if (wr1) wr1.checked = s.winScreen.team === 'team1';
  const wr2 = g('ops-win-team2'); if (wr2) wr2.checked = s.winScreen.team === 'team2';

  // Champ select phase
  setInp('ops-cs-phase', s.champSelect && s.champSelect.phase);

  // Active graphic highlights on operator cards
  GRAPHIC_MAP.forEach(function(gfx) {
    const active = s[gfx.key] && s[gfx.key].visible;
    const card = g('ops-card-' + gfx.key);
    if (card) {
      card.classList.toggle('ops-card-active', !!active);
    }
    const showBtn = g('ops-show-' + gfx.key);
    const hideBtn = g('ops-hide-' + gfx.key);
    if (showBtn) showBtn.className = 'ops-btn ops-btn-show' + (active ? ' is-active' : '');
    if (hideBtn) hideBtn.className = 'ops-btn ops-btn-hide' + (active ? ' is-active' : '');
  });

  // Win team names
  syncOpsWinTeamNames(m);
  // Quick player buttons
  renderOpsLTQuickGrid(s.players, m);
}

// LT quick grid for operator page — same logic, different container
function renderOpsLTQuickGrid(players, match) {
  const grid = g('ops-lt-player-grid');
  if (!grid) return;
  const all = [];
  (players.team1||[]).forEach(p => { if (p.handle||p.name) all.push({...p, teamName:match.team1.name, teamTag:match.team1.tag, teamColor:match.team1.color}); });
  (players.team2||[]).forEach(p => { if (p.handle||p.name) all.push({...p, teamName:match.team2.name, teamTag:match.team2.tag, teamColor:match.team2.color}); });
  grid._players = all;
  // Only rebuild if player list changed
  const sig = all.map(p=>p.handle+p.name+p.role+p.teamName).join('|');
  if (grid.dataset.sig === sig) return;
  grid.dataset.sig = sig;
  grid.innerHTML = all.map((p,i) =>
    '<button class="player-quick-btn ops-player-btn" onclick="opsQuickLT('+i+')">' +
    '<span class="pqb-handle">'+esc(p.handle||p.name)+'</span>' +
    '<span class="pqb-team">'+esc(p.teamTag||p.teamName)+(p.role?' · '+p.role:'')+'</span>' +
    '</button>'
  ).join('');
}

function opsQuickLT(i) {
  const grid = g('ops-lt-player-grid');
  const p = grid&&grid._players&&grid._players[i]; if (!p) return;
  api('/api/lowerThird', { text:p.handle||p.name, subtext:(p.role?p.role+' · ':'')+p.teamName, supertext:(window._state&&window._state.match&&window._state.match.tournament)||'', teamColor:p.teamColor||'', visible:true });
}

// ── Operator page timer helper ─────────────────────────────────────────────────
function opsStartTimer() {
  const mins = parseInt(g('ops-break-min') && g('ops-break-min').value) || 0;
  const secs = parseInt(g('ops-break-sec') && g('ops-break-sec').value) || 0;
  api('/api/breakScreen', { timerEnd: Date.now() + (mins * 60 + secs) * 1000 });
}

// Sync win team names in operator page
function syncOpsWinTeamNames(m) {
  const t1 = g('ops-win-t1-name'); if (t1) t1.textContent = m.team1.name || 'Team 1';
  const t2 = g('ops-win-t2-name'); if (t2) t2.textContent = m.team2.name || 'Team 2';
}

// ── Live Bar ───────────────────────────────────────────────────────────────────
function syncLiveBar(s) {
  const m = s.match;

  // Scores
  setText('lbar-t1-score', m.team1.score);
  setText('lbar-t2-score', m.team2.score);

  // Win team names
  const wt1 = g('lbar-win-t1'); if (wt1) wt1.textContent = m.team1.tag || m.team1.name || 'T1';
  const wt2 = g('lbar-win-t2'); if (wt2) wt2.textContent = m.team2.tag || m.team2.name || 'T2';

  // Win radio sync
  const wr1 = g('lbar-win-team1'); if (wr1) wr1.checked = s.winScreen.team === 'team1';
  const wr2 = g('lbar-win-team2'); if (wr2) wr2.checked = s.winScreen.team === 'team2';

  // Per-graphic ON/OFF button states and group highlight
  GRAPHIC_MAP.forEach(function(gfx) {
    const active = s[gfx.key] && s[gfx.key].visible;
    const group  = g('lbar-group-' + gfx.key);
    const dot    = g('lbar-dot-'   + gfx.key);
    const showB  = g('lbar-show-'  + gfx.key);
    const hideB  = g('lbar-hide-'  + gfx.key);
    if (group)  group.classList.toggle('lbar-group-active', !!active);
    if (dot)    dot.classList.toggle('active', !!active);
    if (showB)  showB.className = 'lbar-show' + (active ? ' is-on' : '');
    if (hideB)  hideB.className = 'lbar-hide' + (active ? ' is-off' : '');
  });
}

function lbarStartTimer() {
  const mins = parseInt(g('lbar-break-min') && g('lbar-break-min').value) || 0;
  const secs = parseInt(g('lbar-break-sec') && g('lbar-break-sec').value) || 0;
  api('/api/breakScreen', { timerEnd: Date.now() + (mins * 60 + secs) * 1000 });
}
