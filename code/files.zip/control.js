// control.js — Esports GFX Control Panel

const socket = io();
window._state = {};
let bracketRounds = [];
const _pickerContainers = {};

// ── Connection ─────────────────────────────────────────────────────────────────
socket.on('connect', () => {
  const el = document.getElementById('conn-status');
  el.textContent = '⬤ Connected';
  el.className = 'connection-status connected';
});
socket.on('disconnect', () => {
  const el = document.getElementById('conn-status');
  el.textContent = '⬤ Disconnected';
  el.className = 'connection-status disconnected';
});
socket.on('state', (state) => {
  window._state = state;
  syncUI(state);
});

// ── Navigation ─────────────────────────────────────────────────────────────────
document.querySelectorAll('.nav-item').forEach(navEl => {
  navEl.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    navEl.classList.add('active');
    const tab = document.getElementById('tab-' + navEl.dataset.tab);
    if (tab) tab.classList.add('active');
  });
});

// Output URL chips
const GFX_PAGES = [
  ['Scoreboard',   'graphics/scoreboard/'],
  ['Lower Third',  'graphics/lower-third/'],
  ['Head to Head', 'graphics/head2head/'],
  ['Champ Select', 'graphics/champ-select/'],
  ['Bracket',      'graphics/bracket/'],
  ['Break Screen', 'graphics/break-screen/'],
  ['Win Screen',   'graphics/win-screen/'],
];
const urlList = document.getElementById('url-list');
GFX_PAGES.forEach(([label, p]) => {
  const url = 'http://localhost:3000/' + p;
  const chip = document.createElement('div');
  chip.className = 'url-chip';
  chip.title = 'Click to copy: ' + url;
  chip.textContent = label;
  chip.addEventListener('click', () => {
    navigator.clipboard.writeText(url).then(() => {
      chip.textContent = '✓ Copied!';
      setTimeout(() => { chip.textContent = label; }, 1500);
    });
  });
  urlList.appendChild(chip);
});

// ── API helper ─────────────────────────────────────────────────────────────────
async function api(path, body) {
  try {
    const res = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      console.error('API error', path, res.status, err);
    }
    return res.json().catch(() => ({}));
  } catch (e) {
    console.error('Fetch error', path, e);
  }
}

// ── Sync UI from state ─────────────────────────────────────────────────────────
function syncUI(s) {
  if (!s || !s.match || !s.lowerThird || !s.champSelect || !s.breakScreen || !s.winScreen || !s.bracket || !s.players) {
    console.warn('Incomplete state, skipping syncUI', s);
    return;
  }

  const m = s.match;
  const p = s.players;

  setInp('tournament-name', m.tournament);
  setInp('match-format', m.format);
  setInp('match-game', m.game);
  setInp('tournament-logo', m.tournamentLogo);

  setInp('t1-name', m.team1.name);
  setInp('t1-tag', m.team1.tag);
  setInp('t1-logo', m.team1.logo);
  setInp('t1-color-text', m.team1.color);
  setColorPicker('t1-color', m.team1.color);
  setSpan('t1-score', m.team1.score);
  setDotColor('t1-dot', m.team1.color);

  setInp('t2-name', m.team2.name);
  setInp('t2-tag', m.team2.tag);
  setInp('t2-logo', m.team2.logo);
  setInp('t2-color-text', m.team2.color);
  setColorPicker('t2-color', m.team2.color);
  setSpan('t2-score', m.team2.score);
  setDotColor('t2-dot', m.team2.color);

  setText('ls-t1-name', m.team1.name);
  setText('ls-t2-name', m.team2.name);
  setText('ls-t1-score', m.team1.score);
  setText('ls-t2-score', m.team2.score);

  setText('players-t1-label', m.team1.name + ' Roster');
  setText('players-t2-label', m.team2.name + ' Roster');
  setText('cs-t1-label', m.team1.name + ' Draft');
  setText('cs-t2-label', m.team2.name + ' Draft');

  setInpSafe('lt-text',  s.lowerThird.text);
  setInpSafe('lt-sub',   s.lowerThird.subtext);
  setInpSafe('lt-super', s.lowerThird.supertext);

  setInpSafe('break-msg',  s.breakScreen.message);
  setInpSafe('break-sub',  s.breakScreen.subtext);
  setInpSafe('break-next', s.breakScreen.nextMatch);

  setInpSafe('win-msg',       s.winScreen.message);
  setInpSafe('bracket-title', s.bracket.title);

  renderSponsors(m.sponsorLogos || []);
  renderPlayerEditors(p);
  renderLTQuickGrid(p, m);
  renderCSInputs(s.champSelect);

  if (s.bracket && s.bracket.rounds) {
    bracketRounds = s.bracket.rounds;
    renderBracketEditor();
  }
}

// ── DOM helpers ────────────────────────────────────────────────────────────────
function g(id) { return document.getElementById(id); }

function setInp(id, val) {
  const e = g(id);
  if (e && document.activeElement !== e) e.value = val != null ? val : '';
}
function setInpSafe(id, val) { setInp(id, val); }
function setText(id, val) {
  const e = g(id);
  if (e) e.textContent = val != null ? val : '';
}
function setSpan(id, val) { setText(id, val); }
function setColorPicker(id, val) {
  const e = g(id);
  if (e && val && /^#[0-9a-fA-F]{6}$/.test(val)) e.value = val;
}
function setDotColor(id, color) {
  const e = g(id);
  if (e) e.style.background = color || '#1ffaff';
}

// ── Match controls ─────────────────────────────────────────────────────────────
function patchMatch(data) { api('/api/match', data); }

function patchTeam(n, field, value) {
  socket.emit('state:patch', { match: { ['team' + n]: { [field]: value } } });
}

function syncColorFromPicker(n, hex) {
  const textEl = g('t' + n + '-color-text');
  if (textEl && document.activeElement !== textEl) textEl.value = hex;
  patchTeam(n, 'color', hex);
}

function syncColorFromText(n, hex) {
  if (/^#[0-9a-fA-F]{6}$/.test(hex)) {
    setColorPicker('t' + n + '-color', hex);
    patchTeam(n, 'color', hex);
  }
}

function getLTColor(teamKey) {
  return (window._state && window._state.match && window._state.match[teamKey] && window._state.match[teamKey].color)
    ? window._state.match[teamKey].color : '#1ffaff';
}

function patchScore(team, delta) { api('/api/score', { team: team, delta: delta }); }

function resetState() {
  if (confirm('Reset ALL state to defaults? This cannot be undone.')) {
    api('/api/state/reset', {});
  }
}

// ── Graphic visibility ─────────────────────────────────────────────────────────
function showGraphic(name) {
  fetch('/api/graphic/' + name + '/show', { method: 'POST' }).catch(console.error);
}
function hideGraphic(name) {
  fetch('/api/graphic/' + name + '/hide', { method: 'POST' }).catch(console.error);
}

// ── Lower Third ────────────────────────────────────────────────────────────────
function patchLT(data) { api('/api/lowerThird', data); }

function renderLTQuickGrid(players, match) {
  const grid = g('lt-player-grid');
  if (!grid) return;
  const allPlayers = [];
  (players.team1 || []).forEach(p => {
    if (p.handle || p.name) allPlayers.push({ ...p, teamName: match.team1.name, teamTag: match.team1.tag, teamColor: match.team1.color });
  });
  (players.team2 || []).forEach(p => {
    if (p.handle || p.name) allPlayers.push({ ...p, teamName: match.team2.name, teamTag: match.team2.tag, teamColor: match.team2.color });
  });
  grid._players = allPlayers;
  grid.innerHTML = allPlayers.map((p, i) =>
    '<button class="player-quick-btn" onclick="quickLT(' + i + ')">' +
    '<span class="pqb-handle">' + esc(p.handle || p.name) + '</span>' +
    '<span class="pqb-team">' + esc(p.teamTag || p.teamName) + (p.role ? ' · ' + p.role : '') + '</span>' +
    '</button>'
  ).join('');
}

function quickLT(i) {
  const grid = g('lt-player-grid');
  const p = grid && grid._players && grid._players[i];
  if (!p) return;
  api('/api/lowerThird', {
    text: p.handle || p.name,
    subtext: (p.role ? p.role + ' · ' : '') + p.teamName,
    supertext: (window._state && window._state.match && window._state.match.tournament) || '',
    teamColor: p.teamColor || '',
    visible: true
  });
}

// ── Champ Select — champion image picker ───────────────────────────────────────
function patchCS(data) { api('/api/champSelect', data); }

function updateCS(team, type, index, url) {
  const cs = window._state && window._state.champSelect;
  const current = (cs && cs[team] && cs[team][type]) ? cs[team][type].slice() : ['','','','',''];
  current[index] = url;
  api('/api/champSelect', { [team]: { [type]: current } });
}

function renderCSInputs(cs) {
  if (!cs) return;

  ['team1', 'team2'].forEach(function(team) {
    const prefix = team === 'team1' ? 't1' : 't2';

    ['bans', 'picks'].forEach(function(type) {
      const containerId = 'cs-' + prefix + '-' + type + '-inputs';
      const container = g(containerId);
      if (!container) return;

      const values = (cs[team] && cs[team][type]) ? cs[team][type] : ['','','','',''];
      const labels = type === 'bans'
        ? ['Ban 1','Ban 2','Ban 3','Ban 4','Ban 5']
        : ['Pick 1','Pick 2','Pick 3','Pick 4','Pick 5'];

      if (!container.dataset.built) {
        container.dataset.built = '1';
        container.innerHTML = '';

        values.forEach(function(val, i) {
          const key = team + '-' + type + '-' + i;
          const row = document.createElement('div');
          row.className = 'cs-input-row cs-picker-row';

          const lbl = document.createElement('label');
          lbl.textContent = labels[i];

          const pickerContainer = document.createElement('div');
          pickerContainer.className = 'cs-picker-container';

          row.appendChild(lbl);
          row.appendChild(pickerContainer);
          container.appendChild(row);

          _pickerContainers[key] = pickerContainer;

          Champions.buildPicker(pickerContainer, function(champ) {
            updateCS(team, type, i, champ.url || '');
          }, val);
        });

      } else {
        // Update existing pickers from state without rebuilding
        values.forEach(function(val, i) {
          const key = team + '-' + type + '-' + i;
          const pickerContainer = _pickerContainers[key];
          if (pickerContainer) Champions.updatePickerValue(pickerContainer, val);
        });
      }
    });
  });
}

// ── Break Screen ───────────────────────────────────────────────────────────────
function patchBreak(data) { api('/api/breakScreen', data); }

function startBreakTimer() {
  const mins = parseInt(g('break-timer-min').value) || 0;
  const secs = parseInt(g('break-timer-sec').value) || 0;
  api('/api/breakScreen', { timerEnd: Date.now() + (mins * 60 + secs) * 1000 });
}

function clearBreakTimer() { api('/api/breakScreen', { timerEnd: null }); }

// ── Win Screen ─────────────────────────────────────────────────────────────────
function patchWin(data) { api('/api/winScreen', data); }

// ── Bracket ────────────────────────────────────────────────────────────────────
function patchBracket(data) { api('/api/bracket', data); }
function syncBracket() { api('/api/bracket', { rounds: bracketRounds }); }

function addBracketRound() {
  bracketRounds.push({ label: 'Round ' + (bracketRounds.length + 1), matches: [{ team1: { name: '', score: 0 }, team2: { name: '', score: 0 }, complete: false }] });
  renderBracketEditor();
  syncBracket();
}

function addBracketMatch(ri) {
  if (!bracketRounds[ri]) return;
  bracketRounds[ri].matches.push({ team1: { name: '', score: 0 }, team2: { name: '', score: 0 }, complete: false });
  renderBracketEditor();
  syncBracket();
}

function removeBracketRound(ri) {
  bracketRounds.splice(ri, 1);
  renderBracketEditor();
  syncBracket();
}

function renderBracketEditor() {
  const container = g('bracket-rounds');
  if (!container) return;
  container.innerHTML = bracketRounds.map(function(round, ri) {
    return '<div class="bracket-round">' +
      '<div class="bracket-round-header">' +
      '<input type="text" class="br-label" data-ri="' + ri + '" value="' + esc(round.label || '') + '" style="flex:1;font-weight:700" placeholder="Round name">' +
      '<button class="btn btn-sm btn-danger" onclick="removeBracketRound(' + ri + ')">Remove Round</button>' +
      '</div>' +
      round.matches.map(function(match, mi) {
        return '<div class="bracket-match">' +
          '<input type="text" class="br-t1name" data-ri="' + ri + '" data-mi="' + mi + '" placeholder="Team 1" value="' + esc(match.team1 && match.team1.name ? match.team1.name : '') + '">' +
          '<input type="number" class="br-t1score score-in" data-ri="' + ri + '" data-mi="' + mi + '" placeholder="S" min="0" value="' + (match.team1 && match.team1.score != null ? match.team1.score : '') + '">' +
          '<span style="color:var(--accent);font-weight:700;padding:0 6px">vs</span>' +
          '<input type="text" class="br-t2name" data-ri="' + ri + '" data-mi="' + mi + '" placeholder="Team 2" value="' + esc(match.team2 && match.team2.name ? match.team2.name : '') + '">' +
          '<input type="number" class="br-t2score score-in" data-ri="' + ri + '" data-mi="' + mi + '" placeholder="S" min="0" value="' + (match.team2 && match.team2.score != null ? match.team2.score : '') + '">' +
          '<label style="display:flex;align-items:center;gap:4px;font-size:12px;color:var(--accent);white-space:nowrap">' +
          '<input type="checkbox" class="br-done" data-ri="' + ri + '" data-mi="' + mi + '"' + (match.complete ? ' checked' : '') + '> Done</label>' +
          '</div>';
      }).join('') +
      '<button class="btn btn-sm" style="margin-top:6px" onclick="addBracketMatch(' + ri + ')">+ Add Match</button>' +
      '</div>';
  }).join('');
  container.oninput = handleBracketInput;
  container.onchange = handleBracketInput;
}

function handleBracketInput(e) {
  const t = e.target;
  const ri = parseInt(t.dataset.ri);
  const mi = parseInt(t.dataset.mi);
  if (isNaN(ri) || !bracketRounds[ri]) return;
  if (t.classList.contains('br-label')) { bracketRounds[ri].label = t.value; }
  else if (!isNaN(mi) && bracketRounds[ri].matches[mi]) {
    const match = bracketRounds[ri].matches[mi];
    if (t.classList.contains('br-t1name'))  match.team1.name  = t.value;
    if (t.classList.contains('br-t1score')) match.team1.score = parseInt(t.value) || 0;
    if (t.classList.contains('br-t2name'))  match.team2.name  = t.value;
    if (t.classList.contains('br-t2score')) match.team2.score = parseInt(t.value) || 0;
    if (t.classList.contains('br-done'))    match.complete    = t.checked;
  }
  syncBracket();
}

// ── Players ────────────────────────────────────────────────────────────────────
function renderPlayerEditors(players) {
  ['team1', 'team2'].forEach(function(team) {
    const prefix = team === 'team1' ? 't1' : 't2';
    const container = g(prefix + '-roster');
    if (!container) return;
    const list = players[team] || [];

    if (!container.dataset.built) {
      container.dataset.built = '1';
      container.innerHTML = list.map(function(p, i) {
        return '<div class="player-row-edit">' +
          '<div><div class="player-num">P' + (i+1) + ' Handle / IGN</div>' +
          '<input type="text" data-team="' + team + '" data-index="' + i + '" data-field="handle" placeholder="Handle"></div>' +
          '<div><div class="player-num">Real Name</div>' +
          '<input type="text" data-team="' + team + '" data-index="' + i + '" data-field="name" placeholder="Full name"></div>' +
          '<div><div class="player-num">Role</div>' +
          '<input type="text" data-team="' + team + '" data-index="' + i + '" data-field="role" placeholder="Top / Jungler…"></div>' +
          '</div>';
      }).join('');
      container.addEventListener('input', function(e) {
        const inp = e.target;
        if (inp.tagName !== 'INPUT') return;
        updatePlayer(inp.dataset.team, parseInt(inp.dataset.index), inp.dataset.field, inp.value);
      });
    }

    container.querySelectorAll('input').forEach(function(inp) {
      if (document.activeElement === inp) return;
      const p = list[inp.dataset.index];
      if (p) inp.value = p[inp.dataset.field] || '';
    });
  });
}

function updatePlayer(team, index, field, value) {
  api('/api/players', { team: team, index: index, data: { [field]: value } });
}

// ── Sponsors ───────────────────────────────────────────────────────────────────
function renderSponsors(logos) {
  const el = g('sponsor-list');
  if (!el) return;
  el.innerHTML = logos.map(function(url, i) {
    return '<div class="sponsor-chip">' +
      '<img src="' + url + '" alt="">' +
      '<span style="max-width:80px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10px">' + url.split('/').pop() + '</span>' +
      '<button onclick="removeSponsor(' + i + ')">✕</button>' +
      '</div>';
  }).join('');
}

function addSponsor() {
  triggerUpload('sponsor-file', function(url) {
    const logos = ((window._state && window._state.match && window._state.match.sponsorLogos) || []).concat([url]);
    api('/api/match', { sponsorLogos: logos });
  });
}

function removeSponsor(i) {
  const logos = ((window._state && window._state.match && window._state.match.sponsorLogos) || []).slice();
  logos.splice(i, 1);
  api('/api/match', { sponsorLogos: logos });
}

// ── File Upload ────────────────────────────────────────────────────────────────
function triggerUpload(inputId, callback) {
  const inp = g(inputId);
  if (!inp) return;
  inp.onchange = async function() {
    const file = inp.files[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    try {
      const res = await fetch('/api/upload', { method: 'POST', body: fd });
      const data = await res.json();
      if (data.url) callback(data.url);
    } catch (e) { console.error('Upload error', e); }
    inp.value = '';
  };
  inp.click();
}

// ── Import ─────────────────────────────────────────────────────────────────────
async function importGSheets() {
  const sheetId = (g('gsheets-id').value || '').trim();
  const apiKey  = (g('gsheets-key').value || '').trim();
  const range   = (g('gsheets-range').value || 'Sheet1').trim();
  if (!sheetId || !apiKey) return showImportResult('gsheets-result', 'Sheet ID and API Key are required.', true);
  showImportResult('gsheets-result', 'Importing…', false);
  const res = await api('/api/import/gsheets', { sheetId, apiKey, range });
  if (!res || res.error) return showImportResult('gsheets-result', 'Error: ' + (res && res.error ? res.error : 'unknown'), true);
  applyImportedPlayers(res.data || []);
  showImportResult('gsheets-result', '✓ Imported ' + (res.data || []).length + ' rows');
}

async function importJson() {
  const file = g('json-file') && g('json-file').files[0];
  if (!file) return showImportResult('import-result', 'Please select a JSON file.', true);
  const fd = new FormData();
  fd.append('file', file);
  const res = await fetch('/api/import/json', { method: 'POST', body: fd }).then(r => r.json()).catch(() => ({ error: 'Upload failed' }));
  if (res.error) return showImportResult('import-result', 'Error: ' + res.error, true);
  const rows = Array.isArray(res.data) ? res.data : [res.data];
  applyImportedPlayers(rows);
  showImportResult('import-result', '✓ Imported ' + rows.length + ' rows from JSON');
}

async function importCsv() {
  const file = g('csv-file') && g('csv-file').files[0];
  if (!file) return showImportResult('import-result', 'Please select a CSV file.', true);
  const fd = new FormData();
  fd.append('file', file);
  const res = await fetch('/api/import/csv', { method: 'POST', body: fd }).then(r => r.json()).catch(() => ({ error: 'Upload failed' }));
  if (res.error) return showImportResult('import-result', 'Error: ' + res.error, true);
  applyImportedPlayers(res.data || []);
  showImportResult('import-result', '✓ Imported ' + (res.data || []).length + ' rows from CSV');
}

function applyImportedPlayers(rows) {
  if (!Array.isArray(rows) || !rows.length) return;
  const m = window._state && window._state.match;
  const t1 = m && m.team1 ? m.team1 : {};
  const t2 = m && m.team2 ? m.team2 : {};
  const t1keys = ['1','team1',(t1.tag||'').toLowerCase(),(t1.name||'').toLowerCase()].filter(Boolean);
  const t2keys = ['2','team2',(t2.tag||'').toLowerCase(),(t2.name||'').toLowerCase()].filter(Boolean);
  const buckets = { team1: [], team2: [] };
  rows.forEach(function(row) {
    const t = (row.team || '').toLowerCase().trim();
    buckets[t1keys.indexOf(t) !== -1 ? 'team1' : 'team2'].push(row);
  });
  ['team1','team2'].forEach(function(team) {
    buckets[team].forEach(function(row, i) {
      if (i >= 5) return;
      api('/api/players', { team, index: i, data: { handle: row.handle || row.ign || '', name: row.name || '', role: row.role || '', country: row.country || '' } });
    });
  });
}

function showImportResult(id, msg, isError) {
  const el = g(id);
  if (!el) return;
  el.textContent = msg;
  el.className = 'import-result show' + (isError ? ' error' : '');
  setTimeout(function() { el.className = 'import-result'; }, 5000);
}

// ── Utility ────────────────────────────────────────────────────────────────────
function esc(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── Init ───────────────────────────────────────────────────────────────────────
Champions.load();
