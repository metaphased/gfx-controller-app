// ADD THIS BLOCK to server.js alongside the other app.get/app.post routes
// It scans public/champions/ and returns a sorted list of champion names + URLs

const CHAMP_DIR = path.join(__dirname, 'public', 'champions');

app.get('/api/champions', (req, res) => {
  try {
    if (!fs.existsSync(CHAMP_DIR)) {
      fs.mkdirSync(CHAMP_DIR, { recursive: true });
      return res.json({ champions: [] });
    }
    const files = fs.readdirSync(CHAMP_DIR);
    const champions = files
      .filter(f => /\.(jpg|jpeg|png|webp|gif)$/i.test(f))
      .map(f => {
        // Strip trailing _0, _1 etc and extension to get clean name
        // e.g. "Leblanc_0.jpg" -> "Leblanc"
        const name = f.replace(/\.[^.]+$/, '').replace(/_\d+$/, '');
        return { name: name, url: '/champions/' + f, file: f };
      })
      // Deduplicate by name (keep first file found)
      .filter((c, i, arr) => arr.findIndex(x => x.name.toLowerCase() === c.name.toLowerCase()) === i)
      .sort((a, b) => a.name.localeCompare(b.name));

    res.json({ champions });
  } catch (e) {
    console.error('Champions scan error:', e.message);
    res.status(500).json({ error: e.message });
  }
});
