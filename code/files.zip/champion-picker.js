// champion-picker.js
// Loads champion list from server, provides searchable picker UI

window.Champions = (function() {
  let _list = []; // [{ name: 'Leblanc', url: '/champions/Leblanc_0.jpg' }, ...]

  async function load() {
    try {
      const res = await fetch('/api/champions');
      const data = await res.json();
      _list = data.champions || [];
      console.log('Champions loaded:', _list.length);
    } catch(e) {
      console.error('Failed to load champions:', e);
    }
  }

  function getList() { return _list; }

  function findByName(name) {
    if (!name) return null;
    const lower = name.toLowerCase().trim();
    return _list.find(c => c.name.toLowerCase() === lower) || null;
  }

  function getUrl(name) {
    const champ = findByName(name);
    return champ ? champ.url : '';
  }

  // Build a searchable picker inside a container element
  // onSelect({ name, url }) called when user picks a champion
  // currentValue can be a name or url string
  function buildPicker(container, onSelect, currentValue) {
    container.innerHTML = '';
    container.style.position = 'relative';

    const current = currentValue
      ? (_list.find(c => c.url === currentValue || c.name.toLowerCase() === (currentValue || '').toLowerCase()) || null)
      : null;

    const wrapper = document.createElement('div');
    wrapper.className = 'champ-picker-wrapper';

    const thumb = document.createElement('div');
    thumb.className = 'champ-thumb';
    if (current && current.url) {
      thumb.style.backgroundImage = 'url(' + current.url + ')';
      thumb.classList.add('has-img');
    }

    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'champ-search-input';
    input.placeholder = _list.length ? 'Search champion…' : 'No champions found in /public/champions/';
    input.value = current ? current.name : '';
    input.autocomplete = 'off';

    const clearBtn = document.createElement('button');
    clearBtn.className = 'champ-clear-btn btn btn-sm';
    clearBtn.textContent = '✕';
    clearBtn.title = 'Clear';
    clearBtn.addEventListener('mousedown', function(e) {
      e.preventDefault();
      input.value = '';
      thumb.style.backgroundImage = '';
      thumb.classList.remove('has-img');
      onSelect({ name: '', url: '' });
      dropdown.style.display = 'none';
    });

    const dropdown = document.createElement('div');
    dropdown.className = 'champ-dropdown';
    dropdown.style.display = 'none';

    function renderDropdown(filter) {
      const q = (filter || '').toLowerCase().trim();
      const matches = q ? _list.filter(c => c.name.toLowerCase().includes(q)) : _list;
      dropdown.innerHTML = '';

      if (!matches.length) {
        const none = document.createElement('div');
        none.className = 'champ-no-results';
        none.textContent = q ? 'No match for "' + filter + '"' : 'No champions loaded';
        dropdown.appendChild(none);
        return;
      }

      matches.slice(0, 40).forEach(function(champ) {
        const item = document.createElement('div');
        item.className = 'champ-option';

        const img = document.createElement('div');
        img.className = 'champ-option-img';
        img.style.backgroundImage = 'url(' + champ.url + ')';

        const label = document.createElement('span');
        label.textContent = champ.name;

        item.appendChild(img);
        item.appendChild(label);

        item.addEventListener('mousedown', function(e) {
          e.preventDefault();
          input.value = champ.name;
          thumb.style.backgroundImage = 'url(' + champ.url + ')';
          thumb.classList.add('has-img');
          onSelect(champ);
          dropdown.style.display = 'none';
        });

        dropdown.appendChild(item);
      });
    }

    input.addEventListener('focus', function() {
      renderDropdown(input.value);
      dropdown.style.display = 'block';
    });

    input.addEventListener('input', function() {
      renderDropdown(input.value);
      dropdown.style.display = 'block';
      if (!input.value.trim()) {
        thumb.style.backgroundImage = '';
        thumb.classList.remove('has-img');
        onSelect({ name: '', url: '' });
      }
    });

    input.addEventListener('blur', function() {
      setTimeout(function() {
        dropdown.style.display = 'none';
        const match = findByName(input.value);
        if (input.value && !match) {
          input.value = '';
          thumb.style.backgroundImage = '';
          thumb.classList.remove('has-img');
          onSelect({ name: '', url: '' });
        }
      }, 160);
    });

    wrapper.appendChild(thumb);
    wrapper.appendChild(input);
    wrapper.appendChild(clearBtn);
    wrapper.appendChild(dropdown);
    container.appendChild(wrapper);
  }

  function updatePickerValue(container, nameOrUrl) {
    const input = container.querySelector('.champ-search-input');
    const thumb = container.querySelector('.champ-thumb');
    if (!input || !thumb || document.activeElement === input) return;

    if (!nameOrUrl) {
      input.value = '';
      thumb.style.backgroundImage = '';
      thumb.classList.remove('has-img');
      return;
    }
    const champ = _list.find(c => c.url === nameOrUrl || c.name.toLowerCase() === nameOrUrl.toLowerCase());
    if (champ) {
      input.value = champ.name;
      thumb.style.backgroundImage = 'url(' + champ.url + ')';
      thumb.classList.add('has-img');
    }
  }

  return { load, getList, findByName, getUrl, buildPicker, updatePickerValue };
})();
