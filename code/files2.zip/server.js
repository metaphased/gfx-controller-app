const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const csv = require('csv-parser');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const uploadDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

const makeDefault = () => ({
  match: {
    team1: { name: 'Team One', tag: 'T1', logo: '', color: '#1ffaff', score: 0 },
    team2: { name: 'Team Two', tag: 'T2', logo: '', color: '#a7a38e', score: 0 },
    game: 'lol', format: 'Bo3', tournament: '', tournamentLogo: '', sponsorLogos: []
  },
  players: {
    team1: Array.from({ length: 5 }, (_, i) => ({ name: '', handle: 'Player ' + (i+1), role: '', country: '' })),
    team2: Array.from({ length: 5 }, (_, i) => ({ name: '', handle: 'Player ' + (i+1), role: '', country: '' }))
  },
  scoreboard:  { visible: false },
  lowerThird:  { visible: false, text: '', subtext: '', supertext: '', side: 'left', teamColor: '' },
  headToHead:  { visible: false },
  champSelect: { visible: false, phase: 'bans1', team1: { bans: ['','','','',''], picks: ['','','','',''] }, team2: { bans: ['','','','',''], picks: ['','','','',''] } },
  bracket:     { visible: false, title: 'TOURNAMENT BRACKET', rounds: [] },
  breakScreen: { visible: false, message: 'BE RIGHT BACK', subtext: '', nextMatch: '', timerEnd: null },
  winScreen:   { visible: false, team: 'team1', message: 'WINS THE SERIES' },
  ticker:      { visible: false, items: [] }
});

function deepMerge(target, source) {
  for (const key of Object.keys(source)) {
    const val = source[key];
    if (val !== null && val !== undefined && typeof val === 'object' && !Array.isArray(val)) {
      if (!target[key] || typeof target[key] !== 'object') target[key] = {};
      deepMerge(target[key], val);
    } else {
      target[key] = val;
    }
  }
  return target;
}

const DATA_DIR   = path.join(__dirname, 'data');
const DATA_FILE  = path.join(DATA_DIR, 'state.json');
const TEAMS_FILE = path.join(DATA_DIR, 'teams.json');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function loadState() {
  try { if (fs.existsSync(DATA_FILE)) return deepMerge(makeDefault(), JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'))); }
  catch (e) { console.error('State load error:', e.message); }
  return makeDefault();
}
function saveState() {
  try { fs.writeFileSync(DATA_FILE, JSON.stringify(state, null, 2)); }
  catch (e) { console.error('State save error:', e.message); }
}
function loadTeams() {
  try { if (fs.existsSync(TEAMS_FILE)) return JSON.parse(fs.readFileSync(TEAMS_FILE, 'utf8')); }
  catch (e) { console.error('Teams load error:', e.message); }
  return [];
}
function saveTeams(teams) {
  try { fs.writeFileSync(TEAMS_FILE, JSON.stringify(teams, null, 2)); }
  catch (e) { console.error('Teams save error:', e.message); }
}

let state = loadState();
function broadcast() { saveState(); io.emit('state', state); }

// ── State ──────────────────────────────────────────────────────────────────────
app.get('/api/state', (req, res) => res.json(state));
app.post('/api/state/reset', (req, res) => { state = makeDefault(); broadcast(); res.json({ ok: true }); });

// ── Match ──────────────────────────────────────────────────────────────────────
app.post('/api/match', (req, res) => { deepMerge(state.match, req.body); broadcast(); res.json({ ok: true }); });

app.post('/api/score', (req, res) => {
  const { team, delta } = req.body;
  if (state.match[team]) state.match[team].score = Math.max(0, (state.match[team].score || 0) + Number(delta));
  broadcast(); res.json({ ok: true });
});

app.post('/api/players', (req, res) => {
  const { team, index, data } = req.body;
  if (state.players[team] && state.players[team][index] !== undefined) Object.assign(state.players[team][index], data);
  broadcast(); res.json({ ok: true });
});

app.post('/api/players/bulk', (req, res) => {
  const { team, players } = req.body;
  if (state.players[team] && Array.isArray(players)) {
    players.forEach((p, i) => { if (i < state.players[team].length) Object.assign(state.players[team][i], p); });
  }
  broadcast(); res.json({ ok: true });
});

// Load a saved team into a match slot
app.post('/api/match/load-team', (req, res) => {
  const { slot, teamId } = req.body;
  if (!slot || !teamId) return res.status(400).json({ error: 'slot and teamId required' });
  const team = loadTeams().find(t => t.id === teamId);
  if (!team) return res.status(404).json({ error: 'Team not found' });

  const currentScore = state.match[slot] ? state.match[slot].score : 0;
  state.match[slot] = { name: team.name || '', tag: team.tag || '', logo: team.logo || '', color: team.color || '#1ffaff', score: currentScore };

  if (team.players && Array.isArray(team.players)) {
    team.players.forEach((p, i) => {
      if (i < state.players[slot].length) state.players[slot][i] = Object.assign({}, state.players[slot][i], p);
    });
    for (let i = team.players.length; i < state.players[slot].length; i++) {
      state.players[slot][i] = { name: '', handle: '', role: '', country: '' };
    }
  }

  broadcast(); res.json({ ok: true });
});

// ── Graphics ───────────────────────────────────────────────────────────────────
app.post('/api/graphic/:name/show', (req, res) => { if (state[req.params.name] !== undefined) state[req.params.name].visible = true; broadcast(); res.json({ ok: true }); });
app.post('/api/graphic/:name/hide', (req, res) => { if (state[req.params.name] !== undefined) state[req.params.name].visible = false; broadcast(); res.json({ ok: true }); });
app.post('/api/lowerThird',  (req, res) => { Object.assign(state.lowerThird, req.body);  broadcast(); res.json({ ok: true }); });
app.post('/api/champSelect', (req, res) => { deepMerge(state.champSelect, req.body);      broadcast(); res.json({ ok: true }); });
app.post('/api/breakScreen', (req, res) => { Object.assign(state.breakScreen, req.body);  broadcast(); res.json({ ok: true }); });
app.post('/api/winScreen',   (req, res) => { Object.assign(state.winScreen, req.body);    broadcast(); res.json({ ok: true }); });
app.post('/api/bracket',     (req, res) => { deepMerge(state.bracket, req.body);          broadcast(); res.json({ ok: true }); });
app.post('/api/ticker',      (req, res) => { Object.assign(state.ticker, req.body);       broadcast(); res.json({ ok: true }); });

// ── Teams database ─────────────────────────────────────────────────────────────
app.get('/api/teams', (req, res) => res.json({ teams: loadTeams() }));

app.post('/api/teams/save', (req, res) => {
  const teams = loadTeams();
  const incoming = req.body;
  if (!incoming || !incoming.name) return res.status(400).json({ error: 'Team name required' });
  if (incoming.id) {
    const idx = teams.findIndex(t => t.id === incoming.id);
    if (idx !== -1) teams[idx] = { ...teams[idx], ...incoming };
    else teams.push(incoming);
  } else {
    incoming.id = 'team_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    teams.push(incoming);
  }
  saveTeams(teams);
  res.json({ ok: true, team: incoming });
});

app.post('/api/teams/delete', (req, res) => {
  const { id } = req.body;
  if (!id) return res.status(400).json({ error: 'id required' });
  saveTeams(loadTeams().filter(t => t.id !== id));
  res.json({ ok: true });
});

// ── Champions ──────────────────────────────────────────────────────────────────
const CHAMP_DIR = path.join(__dirname, 'public', 'champions');
app.get('/api/champions', (req, res) => {
  try {
    if (!fs.existsSync(CHAMP_DIR)) { fs.mkdirSync(CHAMP_DIR, { recursive: true }); return res.json({ champions: [] }); }
    const champions = fs.readdirSync(CHAMP_DIR)
      .filter(f => /\.(jpg|jpeg|png|webp|gif)$/i.test(f))
      .map(f => ({ name: f.replace(/\.[^.]+$/, '').replace(/_\d+$/, ''), url: '/champions/' + f, file: f }))
      .filter((c, i, arr) => arr.findIndex(x => x.name.toLowerCase() === c.name.toLowerCase()) === i)
      .sort((a, b) => a.name.localeCompare(b.name));
    res.json({ champions });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Uploads / Import ───────────────────────────────────────────────────────────
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  res.json({ ok: true, url: '/uploads/' + req.file.filename });
});

app.post('/api/import/csv', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  const results = [];
  fs.createReadStream(req.file.path).pipe(csv())
    .on('data', d => results.push(d))
    .on('end', () => res.json({ ok: true, data: results }))
    .on('error', e => res.status(400).json({ error: e.message }));
});

app.post('/api/import/json', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  try { res.json({ ok: true, data: JSON.parse(fs.readFileSync(req.file.path, 'utf8')) }); }
  catch (e) { res.status(400).json({ error: 'Invalid JSON' }); }
});

app.post('/api/import/gsheets', async (req, res) => {
  const { sheetId, apiKey, range } = req.body;
  if (!sheetId || !apiKey) return res.status(400).json({ error: 'sheetId and apiKey required' });
  try {
    const fetch = require('node-fetch');
    const url = 'https://sheets.googleapis.com/v4/spreadsheets/' + sheetId + '/values/' + encodeURIComponent(range || 'Sheet1') + '?key=' + apiKey;
    const json = await (await fetch(url)).json();
    if (json.error) return res.status(400).json({ error: json.error.message });
    const [headers, ...rows] = json.values || [];
    if (!headers) return res.json({ ok: true, data: [] });
    const data = rows.map(row => { const obj = {}; headers.forEach((h, i) => { obj[h.trim().toLowerCase()] = (row[i] || '').trim(); }); return obj; });
    res.json({ ok: true, data });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── Socket.io ──────────────────────────────────────────────────────────────────
io.on('connection', socket => {
  console.log('Client connected:', socket.id);
  socket.emit('state', state);
  socket.on('state:patch', patch => { deepMerge(state, patch); broadcast(); });
  socket.on('disconnect', () => console.log('Disconnected:', socket.id));
});

server.listen(PORT, () => console.log('\n Esports GFX  ->  http://localhost:' + PORT + '/control/\n'));
